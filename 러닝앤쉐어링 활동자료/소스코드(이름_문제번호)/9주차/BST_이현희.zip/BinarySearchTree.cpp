#include "BinarySearchTree.h"
#include <iostream>

const int SUCCEED = 0;
const int FAILED = -1;
const int LEFT = 0;
const int RIGHT = 1;

Node::Node(int key_value, Node* r_value, Node* l_value) {
	this->key = key_value;
	this->r = r_value;
	this->l = l_value;
}
void BinarySearchTree::Init() {
	this->dummy = new Node(0XFFFFFF, nullptr, nullptr);
}
int BinarySearchTree::Search(int key_value) {
	P = dummy;
	N = P->l;
	if (N == nullptr) {
		std::cout << "Search Failed!" << std::endl;
		return FAILED;
	}

	while (N->key != key_value) {
		P = N;
		if (N->key < key_value)
			N = P->r;
		else if (N->key > key_value)
			N = P->l;

		if (N == nullptr) {
			std::cout << "Search Failed!" << std::endl;
			return FAILED;
		}
	}
	std::cout << "Search Succeed!" << std::endl;
	return SUCCEED;
}
int BinarySearchTree::Insert(int key_value) {

	int search_result = Search(key_value);
	if (search_result == SUCCEED) {
		std::cout << "Insert Failed!" << std::endl;
		return FAILED;
	}
	else {
		int direction = getDirection(key_value);
		if (direction == LEFT)
			P->l = new Node(key_value, nullptr, nullptr);
		else
			P->r = new Node(key_value, nullptr, nullptr);
	}

	std::cout << "Insert Succeed!" << std::endl;
	return SUCCEED;
}
int BinarySearchTree::getDirection(int key_value) {
	if (P->key > key_value)
		return LEFT;	//left
	else if (P->key < key_value)
		return RIGHT;	//right
}
int BinarySearchTree::Delete(int key_value) {
	int search_result = Search(key_value);

	if (search_result == FAILED) {
		std::cout << "Delete Failed!" << std::endl;
		return FAILED;
	}
	else {
		int direction = getDirection(key_value);
		if (N->l == nullptr && N->r == nullptr) {
			if (direction == LEFT)
				P->l = nullptr;
			else
				P->r = nullptr;
			delete N;
		}
		else if (N->l != nullptr && N->r == nullptr) {
			N = N->l;
			if (direction == LEFT)
				P->l = N;
			else
				P->r = N;
		}
		else if(N->l == nullptr && N->r != nullptr){
			N = N->r;
			if (direction == LEFT)
				P->l = N;
			else
				P->r = N;
		}
		else if (N->l != nullptr && N->r != nullptr) {
			Node* PP = P;
			Node* NN = N;
			PP = NN;
			NN = NN->r;
			while (NN->l != nullptr) {
				PP = NN;
				NN = NN->l;
			}
			N->key = NN->key;
			delete NN;
			PP->l = nullptr;
		}
	}

	std::cout << "Delete Succeed!" << std::endl;
	return SUCCEED;

}