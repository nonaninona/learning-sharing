#pragma once


class Node {
public:
	int key;
	Node *r, *l;
	Node(int key_value, Node* r_value, Node* l_value);
};

class BinarySearchTree
{
public:
	Node* dummy;
	Node* P;
	Node* N;

	void Init();
	int Search(int key_value);
	int getDirection(int key_value);
	int Insert(int key_value);
	int Delete(int key_value);
};