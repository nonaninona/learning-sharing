#include "BinarySearchTree.h"

int main() {
	BinarySearchTree BST;

	BST.Init();
	BST.Insert(3);
	BST.Insert(1);
	BST.Insert(5);
	BST.Insert(6);
	BST.Insert(4);
	BST.Delete(3);
}