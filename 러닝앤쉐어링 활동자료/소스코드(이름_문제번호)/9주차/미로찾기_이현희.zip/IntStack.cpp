#include "IntStack.h"
#include <iostream>

void IntStack::Init() {
	this->top = -1;
}
bool IntStack::isEmpty() {
	return this->top == -1;
}
bool IntStack::isFull() {
	return this->top == STACK_SIZE;
}
void IntStack::push(int arg){
	if (isFull()) {
		std::cout << "Stack is Full! Can't Push!" << std::endl;
		return;
	}
	this->top++;
	this->Array[top] = arg;
}
int IntStack::pop(){
	if (isEmpty()) {
		std::cout << "Stack is Empty! Can't Pop!" << std::endl;
	}
	else {
		int oldTop = this->top;
		top--;
		return Array[oldTop];
	}
}
