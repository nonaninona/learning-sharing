#pragma once
const int STACK_SIZE = 1000;

class IntStack
{
private:
	int Array[STACK_SIZE];
	int top;

public:
	void Init();
	bool isEmpty();
	bool isFull();
	void push(int arg);
	int pop();


};

