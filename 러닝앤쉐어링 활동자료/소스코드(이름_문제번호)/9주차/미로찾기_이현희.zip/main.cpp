#include "IntStack.h"
#include <iostream>

bool find(int **Map, int MapWidth, int MapHeight) {

	int i = 0;
	int j = 0;
	bool isFind = false;
	IntStack StackI;
	IntStack StackJ;
	StackI.Init();
	StackJ.Init();

	while (true) {

		if (i == MapHeight - 1 && j == MapWidth -1) {
			isFind = true;
			break;
		}
		if (i + 1 < MapHeight && Map[i + 1][j] == 0) {
			Map[i][j] = 1;
			StackI.push(i);
			StackJ.push(j);
			i++;
			continue;
		}
		else if (i - 1 > -1 && Map[i - 1][j] == 0) {
			Map[i][j] = 1;
			StackI.push(i);
			StackJ.push(j);
			i--;
			continue;
		}
		else if (j + 1 < MapWidth && Map[i][j + 1] == 0) {
			Map[i][j] = 1;
			StackI.push(i);
			StackJ.push(j);
			j++;
			continue;
		}
		else if (j - 1 > -1 && Map[i][j - 1] == 0) {
			Map[i][j] = 1;
			StackI.push(i);
			StackJ.push(j);
			j--;
			continue;
		}
		else {
			if (StackI.isEmpty() && StackJ.isEmpty()) {
				isFind = false;
				break;
			}
			Map[i][j] = 1;
			i = StackI.pop();
			j = StackJ.pop();
		}
	}

	return isFind;
}

int main() {
	int MapWidth;
	int MapHeight;
	std::cout << "Input MapWidth : ";
	std::cin >> MapWidth;
	std::cout << "Input MapHeight : ";
	std::cin >> MapHeight;

	int** Map = new int*[MapHeight];
	for (int i = 0; i < MapHeight; i++)
		Map[i] = new int[MapWidth];

	std::cout << "Input Map" << std::endl;
	for (int i = 0; i < MapHeight; i++) {
		for (int j = 0; j < MapWidth; j++) {
			std::cin >> Map[i][j];
		}
	}

	bool isFind = find(Map, MapWidth, MapHeight);

	if (isFind)
		std::cout << "Can Find Path" << std::endl;
	else
		std::cout << "Can't Find Path" << std::endl;

}